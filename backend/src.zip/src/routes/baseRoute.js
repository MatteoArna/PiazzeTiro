const express = require('express');
const { authenticate } = require('../middleware/authMiddleware');

function createBaseRouter(controller, additionalRoutes = {}) {
  const router = express.Router();

  // Applica il middleware di autenticazione a tutte le route
  router.use(authenticate);
  console.log('Controller:', controller);
  router.get('/', (req, res) => controller.findAll(req, res));
  router.get('/:id', (req, res) => controller.findOne(req, res));
  router.post('/', (req, res) => controller.create(req, res));
  router.put('/:id', (req, res) => controller.update(req, res));
  router.delete('/:id', (req, res) => controller.delete(req, res));

  // Add additional routes
  Object.keys(additionalRoutes).forEach((method) => {
    router[method](additionalRoutes[method].path, additionalRoutes[method].handler);
  });

  return router;
}

module.exports = createBaseRouter;