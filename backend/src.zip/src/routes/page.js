const PageController = require('../controllers/pageController');
const createBaseRouter = require('./baseRoute');

const router = createBaseRouter(PageController, {
  get: {
    path: '/type/:typeId',
    handler: (req, res) => PageController.getPageByType(req, res),
  },
});

module.exports = router;