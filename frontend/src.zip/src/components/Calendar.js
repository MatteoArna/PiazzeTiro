import React from 'react';
import '../styles/Calendar.css';

const Calendar = () => {
  return (
    <div className="calendar">
      <h2>Il mio Calendario</h2>
      <div className="calendar-content">
        {/* Contenuto del calendario */}
      </div>
    </div>
  );
};

export default Calendar;
