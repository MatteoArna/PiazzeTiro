import React, { useState, useEffect } from 'react';
import Markdown from 'markdown-to-jsx';
import '../styles/PageDetailsModal.css';
import manutenzioneIcon from '../assets/maintenance.png';
import documentiIcon from '../assets/info.png';
import sicurezzaIcon from '../assets/warning.png';
import { useAuth } from '../hooks/useAuth'; // Assicurati di avere questo hook per ottenere il token

const PageDetailsModal = ({ page, onClose }) => {
  const { auth } = useAuth();
  const [fileUrl, setFileUrl] = useState(null);

  useEffect(() => {
    if (page.file) {
      const fetchFile = async () => {
        try {
          const response = await fetch(`${process.env.REACT_APP_API_URL}/uploads/${page.file.split('/').pop()}`, {
            headers: {
              Authorization: `Bearer ${auth.token}`
            }
          });

          if (response.ok) {
            const blob = await response.blob();
            setFileUrl(URL.createObjectURL(blob));
          } else {
            console.error('Error fetching file:', response.statusText);
          }
        } catch (error) {
          console.error('Error fetching file:', error);
        }
      };

      fetchFile();
    }
  }, [page.file, auth.token]);

  const getIcon = (type) => {
    switch (type) {
      case 0:
        return documentiIcon;
      case 1:
        return sicurezzaIcon;
      case 2:
        return manutenzioneIcon;
      default:
        return null;
    }
  };

  const getType = (type) => {
    switch (type) {
      case 0:
        return 'Informazioni';
      case 1:
        return 'Attenzione';
      case 2:
        return 'Manutenzione';
      default:
        return null;
    }
  };

  const isImage = (filePath) => {
    const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp'];
    const extension = filePath.split('.').pop().toLowerCase();
    return imageExtensions.includes(extension);
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <button className="close-button" onClick={onClose}>&times;</button>
        <div className="modal-header">
          <img src={getIcon(page.typeId)} alt={getType(page.typeId)} />
          <h3>{getType(page.typeId)}</h3>
        </div>
        <div className="modal-summary">
          {page.summary}
        </div>
        <hr />
        <div className="modal-content-text">
          <Markdown>{page.content}</Markdown>
        </div>
        {page.file && fileUrl && (
          <div className="modal-file-preview">
            {isImage(page.file) ? (
              <img src={fileUrl} alt="Preview" className="file-preview" />
            ) : (
              <a href={fileUrl} download className="file-download">Download File</a>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default PageDetailsModal;
